<!doctype html>
<?php
set_include_path(get_include_path() . PATH_SEPARATOR . __DIR__.'/libs/google-api-php-client-master/src');
?>
<html>
<head>
	<meta charset="utf-8">
	<title>SKGadi's eLibrary</title>
	<link rel="icon" type="image/x-icon" href="images/favicon.ico" />
	<link rel="stylesheet" href="css/font-cm.css">
	<link rel="stylesheet" href="css/font-uc.css">
	<link rel="stylesheet" href="css/web-style.css">
	
	<script src="libs/jquery-3.1.0.min.js"></script>
	<meta name="google-signin-scope" content="https://www.googleapis.com/auth/spreadsheets">
	<meta name="google-signin-client_id" content="283101023526-4o4jti8tl8cusebbogg2qlhpva45uon1.apps.googleusercontent.com">
	<script src="https://apis.google.com/js/platform.js" async defer></script>
	
	<!--meta name="google-signin-client_id" content="1986186878-tkgmk6k1j1euov5k21fqk7rqh3ncj20n.apps.googleusercontent.com"-->
	
	
	 
	  <!--8XHgm37rwws3aDVFfw6oQk-E -->
</head>
<body class="Font001" >
Suresh Kumar Gadi
<div id="profile" style="margin: 0 20px;">
  <b class="name"></b><br/>
  <i class="email"></i>
</div>
<div class="g-signin2" data-onsuccess="onSignIn"></div>

<?php
include_once __DIR__ . '/../vendor/autoload.php';
include_once "templates/base.php";


define('APPLICATION_NAME', 'Google Sheets API PHP Quickstart');
define('CREDENTIALS_PATH', '~/.credentials/sheets.googleapis.com-php-quickstart.json');
define('CLIENT_SECRET_PATH', 'libs/client_secret.json');
echo get_include_path();

// If modifying these scopes, delete your previously saved credentials
// at ~/.credentials/sheets.googleapis.com-php-quickstart.json
define('SCOPES', implode(' ', array(
  Google_Service_Sheets::SPREADSHEETS_READONLY)
));
?>


<script src="js/scripts.js"></script>
</body>
</html>