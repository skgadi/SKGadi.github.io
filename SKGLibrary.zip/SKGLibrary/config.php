<?php
$DatabaseName = "localhost";
$DatabaseUser = "eLib";
$DatabasePassword = "#jRf0J";
$MySQLHost = "localhost";
$LoginUserID = "Suresh";
$LoginPassword = "Password";
?>