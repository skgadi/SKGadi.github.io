DOI, ISBN and URL to Bibtex converter
=============

Generates a Bibtex entry from a given DOI, ISBN or URL
